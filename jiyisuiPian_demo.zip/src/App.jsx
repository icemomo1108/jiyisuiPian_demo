import { useState } from 'react'

function App() {
  const [messages, setMessages] = useState([
    { role: "system", content: "你是李婶，玩家隔壁的邻居，五十多岁，上海口音，说话啰嗦又热情，但心中有秘密。" },
    { role: "assistant", content: "哎呀你可算回来了，我还以为你……哎呀不说了，你屋子里我可不敢进啊。" }
  ]);
  const [input, setInput] = useState("");

  const handleSend = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: "user", content: input }];
    setMessages(newMessages);
    setInput("");

    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: newMessages
      })
    });
    const data = await res.json();
    const reply = data.choices?.[0]?.message?.content || "李婶没听清楚你说什么……";
    setMessages([...newMessages, { role: "assistant", content: reply }]);
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl mb-4">🧩 记忆碎片：李婶对话 DEMO</h1>
      <div className="bg-gray-100 p-4 rounded h-96 overflow-y-scroll">
        {messages.map((m, i) => (
          <div key={i} className="mb-2">
            <b>{m.role === "user" ? "你" : m.role === "assistant" ? "李婶" : ""}：</b> {m.content}
          </div>
        ))}
      </div>
      <div className="mt-4 flex">
        <input
          className="border flex-1 p-2 mr-2"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="输入你想问李婶的内容..."
        />
        <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={handleSend}>
          发送
        </button>
      </div>
    </div>
  );
}

export default App
